export const statusLoading = "loading";
export const statusLoaded = "loaded";
export const statusApplied = "applied";
export const statusEntered = "entered";
export const statusError = "error";
export const statusNative = "native";
