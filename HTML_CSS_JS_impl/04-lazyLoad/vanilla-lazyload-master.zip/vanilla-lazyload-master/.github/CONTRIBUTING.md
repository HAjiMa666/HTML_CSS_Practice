Thank you for taking the time to contribute!

To report a bug or request an enhancement or a feature, use the [issues page](https://github.com/verlok/vanilla-lazyload/issues) on github

If you just want to show your appreciation for this script, how about [buying a coffee](https://ko-fi.com/verlok) to its author?

If you want to contribute actively with your own code, please:

1. fork the repo on your namespace
2. open a new branch
3. develop your contribution on the branch
4. create a pull request towards this repo

I recommend to do **one pull request per feature** to make sure your contribution is easy to review and accept.

Thank you and... may the force be with you!
